#!/bin/bash
cal
date
echo "This is simple rpm"


